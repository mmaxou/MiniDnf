// 用户认证状态管理
export function initAuth() {
    // 监听认证状态变化
    firebase.auth().onAuthStateChanged((user) => {
        if (user) {
            // 用户已登录
            console.log('用户已登录:', user.email);
            // 这里可以添加登录后的跳转逻辑
        } else {
            // 用户未登录
            console.log('用户未登录');
        }
    });
}

// 用户注册
export async function registerUser(email, password) {
    try {
        const userCredential = await firebase.auth().createUserWithEmailAndPassword(email, password);
        return userCredential.user;
    } catch (error) {
        console.error('注册失败:', error.message);
        throw error;
    }
}

// 重置密码
export async function resetPassword(email) {
    try {
        await firebase.auth().sendPasswordResetEmail(email);
        console.log('密码重置邮件已发送');
    } catch (error) {
        console.error('发送密码重置邮件失败:', error.message);
        throw error;
    }
}

// 退出登录
export async function logout() {
    try {
        await firebase.auth().signOut();
        console.log('已退出登录');
    } catch (error) {
        console.error('退出登录失败:', error.message);
        throw error;
    }
}