// 导入Firebase配置
import { initAuth } from './auth.js';

// 创建Vue应用
const app = Vue.createApp({
    data() {
        return {
            // 角色信息
            character: {
                name: '测试角色',
                class: '鬼剑士',
                level: 1,
                avatar: './assets/icons/swordman.png',
                skills: [
                    { id: 1, name: '三段斩', icon: './assets/icons/skills/triple-slash.png' },
                    { id: 2, name: '十字斩', icon: './assets/icons/skills/cross-slash.png' },
                    { id: 3, name: '鬼斩', icon: './assets/icons/skills/ghost-slash.png' }
                ]
            },
            // 疲劳值
            fatigue: 156,
            maxFatigue: 156,
            // 货币
            gold: 1000000,
            cash: 1000,
            // 游戏时间
            currentTime: '',
            // 设置面板
            showSettingsPanel: false,
            settings: {
                soundVolume: 50,
                musicVolume: 50
            },
            // 当前副本
            currentDungeon: {
                name: '训练场'
            },
            // 战斗日志
            battleLogs: [
                { type: 'system', message: '欢迎来到DNF文字觉醒！' },
                { type: 'system', message: '请选择要挑战的副本...' }
            ],
            // 技能状态
            activeSkills: [],
            // 当前怪物
            currentMonster: {
                name: '训练用木桩',
                hp: 1000,
                maxHp: 1000
            },
            // 战斗统计
            currentDPS: '0',
            currentHPS: '0',
            currentRating: 'SSS'
        };
    },
    computed: {
        // 计算疲劳值百分比
        fatiguePercentage() {
            return (this.fatigue / this.maxFatigue) * 100;
        },
        // 计算怪物血量百分比
        monsterHpPercentage() {
            return (this.currentMonster.hp / this.currentMonster.maxHp) * 100;
        }
    },
    methods: {
        // 更新游戏时间
        updateGameTime() {
            const now = new Date();
            this.currentTime = now.toLocaleTimeString();
        },
        // 显示设置面板
        showSettings() {
            this.showSettingsPanel = true;
        },
        // 关闭设置面板
        closeSettings() {
            this.showSettingsPanel = false;
        },
        // 退出游戏
        exitGame() {
            if (confirm('确定要退出游戏吗？')) {
                window.location.href = './character.html';
            }
        },
        // 打开角色面板
        openCharacterPanel() {
            console.log('打开角色面板');
        },
        // 打开装备库
        openInventory() {
            console.log('打开装备库');
        },
        // 切换自动战斗
        toggleAutoFight() {
            console.log('切换自动战斗');
        },
        // 打开社交系统
        openSocial() {
            console.log('打开社交系统');
        },
        // 打开任务日志
        openQuests() {
            console.log('打开任务日志');
        },
        // 打开商城
        openShop() {
            console.log('打开商城');
        },
        // 添加战斗日志
        addBattleLog(type, message) {
            this.battleLogs.push({ type, message });
            // 保持最新的日志可见
            this.$nextTick(() => {
                const battleLog = this.$refs.battleLog;
                battleLog.scrollTop = battleLog.scrollHeight;
            });
        },
        // 模拟战斗
        simulateBattle() {
            // 这里添加战斗相关的逻辑
            this.addBattleLog('damage', '你对训练用木桩造成了100点伤害！');
            this.currentMonster.hp = Math.max(0, this.currentMonster.hp - 100);
            this.updateBattleStats();
        },
        // 更新战斗统计
        updateBattleStats() {
            // 模拟DPS和HPS计算
            this.currentDPS = '1234';
            this.currentHPS = '567';
            // 根据表现动态更新评级
            const ratings = ['SSS', 'SS', 'S', 'A', 'B', 'C', 'D', 'F'];
            this.currentRating = ratings[Math.floor(Math.random() * 3)];
        }
    },
    mounted() {
        // 初始化认证状态监听
        initAuth();
        // 启动游戏时钟
        this.updateGameTime();
        setInterval(this.updateGameTime, 1000);
        // 模拟战斗演示
        setInterval(this.simulateBattle, 2000);
    }
});

// 挂载Vue应用
app.mount('#app');