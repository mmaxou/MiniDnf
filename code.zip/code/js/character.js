// 导入Firebase配置
import { initAuth } from './auth.js';

// 创建Vue应用
const app = Vue.createApp({
    data() {
        return {
            showCreateForm: true,
            characters: [],
            selectedCharacter: null,
            selectedProfession: null,
            nameError: '',
            canCreate: false,
            newCharacter: {
                name: ''
            },
            professions: [
                {
                    id: 1,
                    name: '鬼剑士',
                    icon: './assets/icons/swordman.png',
                    story: '在这片大陆上，鬼剑士是一个充满传奇色彩的职业。他们继承了上古剑术的精髓，以无与伦比的剑技闻名于世。每一个鬼剑士都背负着守护阿拉德大陆的使命，他们的剑既是正义的象征，也是邪恶的克星。',
                    skills: [
                        { id: 1, name: '三段斩', icon: './assets/icons/skills/triple-slash.png' },
                        { id: 2, name: '十字斩', icon: './assets/icons/skills/cross-slash.png' },
                        { id: 3, name: '鬼斩', icon: './assets/icons/skills/ghost-slash.png' }
                    ],
                    attributes: {
                        strength: 90,
                        intelligence: 40,
                        vitality: 70,
                        spirit: 50
                    },
                    advancedClasses: ['剑魂', '鬼泣', '狂战士', '阿修罗']
                },
                {
                    id: 2,
                    name: '神枪手',
                    icon: './assets/icons/gunner.png',
                    story: '神枪手是来自德洛斯帝国的精英射手，他们掌握着最先进的枪械技术。在战场上，神枪手以精准的射击和灵活的走位著称。他们不仅是优秀的战士，更是科技与战斗艺术的完美结合体。',
                    skills: [
                        { id: 1, name: '多重射击', icon: './assets/icons/skills/multi-shot.png' },
                        { id: 2, name: '手雷投掷', icon: './assets/icons/skills/grenade.png' },
                        { id: 3, name: '空中射击', icon: './assets/icons/skills/aerial-shot.png' }
                    ],
                    attributes: {
                        strength: 60,
                        intelligence: 70,
                        vitality: 50,
                        spirit: 70
                    },
                    advancedClasses: ['漫游枪手', '枪炮师', '机械师', '弹药专家']
                },
                {
                    id: 3,
                    name: '格斗家',
                    icon: './assets/icons/fighter.png',
                    story: '格斗家来自武术圣地赛利亚，他们是体术的集大成者。通过不懈的修炼，格斗家将自身的气力提升到了极致。他们的每一招每一式都蕴含着强大的力量，是近身战斗的不二之选。',
                    skills: [
                        { id: 1, name: '崩拳', icon: './assets/icons/skills/burst-punch.png' },
                        { id: 2, name: '回旋踢', icon: './assets/icons/skills/spinning-kick.png' },
                        { id: 3, name: '气功波', icon: './assets/icons/skills/energy-blast.png' }
                    ],
                    attributes: {
                        strength: 80,
                        intelligence: 50,
                        vitality: 80,
                        spirit: 40
                    },
                    advancedClasses: ['气功师', '散打', '街霸', '柔道家']
                },
                {
                    id: 4,
                    name: '圣职者',
                    icon: './assets/icons/priest.png',
                    story: '圣职者是光明神殿的虔诚信徒，他们既是治愈者，也是驱魔人。圣职者掌握着神圣的力量，可以治愈伤痛，也可以惩戒邪恶。在黑暗降临时，他们是人们最后的希望。',
                    skills: [
                        { id: 1, name: '圣光普照', icon: './assets/icons/skills/holy-light.png' },
                        { id: 2, name: '驱魔之力', icon: './assets/icons/skills/exorcism.png' },
                        { id: 3, name: '治愈术', icon: './assets/icons/skills/healing.png' }
                    ],
                    attributes: {
                        strength: 50,
                        intelligence: 80,
                        vitality: 60,
                        spirit: 90
                    },
                    advancedClasses: ['圣骑士', '蓝拳圣使', '驱魔师', '复仇者']
                },
                {
                    id: 5,
                    name: '暗夜精灵',
                    icon: './assets/icons/thief.png',
                    story: '暗夜精灵是黑暗中的舞者，影子中的猎手。他们来自永夜森林，掌握着独特的暗影技艺。暗夜精灵行动敏捷，善于隐匿，是完美的刺客和盗贼。',
                    skills: [
                        { id: 1, name: '暗影步', icon: './assets/icons/skills/shadow-step.png' },
                        { id: 2, name: '毒刃', icon: './assets/icons/skills/poison-blade.png' },
                        { id: 3, name: '隐身术', icon: './assets/icons/skills/stealth.png' }
                    ],
                    attributes: {
                        strength: 60,
                        intelligence: 70,
                        vitality: 50,
                        spirit: 70
                    },
                    advancedClasses: ['刺客', '死灵术士', '影舞者', '暗影猎手']
                }
            ]
        };
    },
    created() {
        // 初始化时选择鬼剑士职业
        this.selectedProfession = this.professions[0];
        this.checkCanCreate();
    },
    methods: {
        // 选择角色
        selectCharacter(character) {
            this.selectedCharacter = character;
        },

        // 开始游戏
        startGame() {
            if (this.selectedCharacter) {
                // 跳转到游戏页面
                window.location.href = './game.html';
            }
        },

        // 显示创建角色界面
        showCreateCharacter() {
            this.showCreateForm = true;
            this.resetCreateForm();
        },

        // 选择职业
        selectProfession(profession) {
            this.selectedProfession = profession;
            this.checkCanCreate();
        },

        // 检查角色名称
        async checkName() {
            if (!this.newCharacter.name) {
                this.nameError = '请输入角色名称';
                return;
            }

            if (this.newCharacter.name.length < 2 || this.newCharacter.name.length > 12) {
                this.nameError = '角色名称长度必须在2-12个字符之间';
                return;
            }

            try {
                // 检查名称是否已存在
                const nameExists = await this.checkNameExists(this.newCharacter.name);
                if (nameExists) {
                    this.nameError = '该角色名称已被使用';
                } else {
                    this.nameError = '';
                }
            } catch (error) {
                console.error('检查角色名称时出错:', error);
                this.nameError = '检查角色名称时出错';
            }

            this.checkCanCreate();
        },

        // 检查名称是否已存在
        async checkNameExists(name) {
            // 这里需要实现与Firebase数据库的交互
            // 临时返回false，实际应该查询数据库
            return false;
        },

        // 检查是否可以创建角色
        checkCanCreate() {
            this.canCreate = this.selectedProfession && 
                           this.newCharacter.name && 
                           !this.nameError;
        },

        // 创建角色
        async createCharacter() {
            if (!this.canCreate) return;

            try {
                const character = {
                    id: Date.now(),
                    name: this.newCharacter.name,
                    class: this.selectedProfession.name,
                    level: 1,
                    avatar: this.selectedProfession.icon,
                    attributes: this.selectedProfession.attributes,
                    skills: this.selectedProfession.skills
                };

                // 保存角色数据到Firebase
                await this.saveCharacter(character);

                // 添加到本地列表
                this.characters.push(character);

                // 重置表单并返回列表视图
                this.cancelCreate();
            } catch (error) {
                console.error('创建角色时出错:', error);
            }
        },

        // 保存角色数据
        async saveCharacter(character) {
            // 这里需要实现与Firebase数据库的交互
            // 临时实现，实际应该保存到数据库
            console.log('保存角色数据:', character);
        },

        // 取消创建
        cancelCreate() {
            this.showCreateForm = false;
            this.resetCreateForm();
        },

        // 重置创建表单
        resetCreateForm() {
            this.selectedProfession = null;
            this.newCharacter.name = '';
            this.nameError = '';
            this.canCreate = false;
        },

        // 加载角色列表
        async loadCharacters() {
            try {
                // 这里需要实现与Firebase数据库的交互
                // 临时数据，实际应该从数据库加载
                this.characters = [];
            } catch (error) {
                console.error('加载角色列表时出错:', error);
            }
        },

        // 确认删除角色
        async confirmDelete(character) {
            if (confirm(`确定要删除角色 ${character.name} 吗？此操作不可恢复。`)) {
                try {
                    // 从数据库中删除角色
                    await this.deleteCharacterFromDB(character);
                    
                    // 从本地列表中移除角色
                    const index = this.characters.findIndex(c => c.id === character.id);
                    if (index > -1) {
                        this.characters.splice(index, 1);
                    }
                    
                    // 如果删除的是当前选中的角色，清除选中状态
                    if (this.selectedCharacter && this.selectedCharacter.id === character.id) {
                        this.selectedCharacter = null;
                    }
                } catch (error) {
                    console.error('删除角色时出错:', error);
                    alert('删除角色失败，请稍后重试');
                }
            }
        },

        // 从数据库中删除角色
        async deleteCharacterFromDB(character) {
            // 这里需要实现与Firebase数据库的交互
            // 临时实现，实际应该从数据库中删除
            console.log('从数据库中删除角色:', character);
        }
    },
    mounted() {
        // 初始化认证状态监听
        initAuth();
        // 加载角色列表
        this.loadCharacters();
    }
});

// 挂载Vue应用
app.mount('#app');