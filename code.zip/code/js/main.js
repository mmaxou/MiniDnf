// Firebase配置
const firebaseConfig = {
    // 这里需要替换为实际的Firebase配置信息
    apiKey: "your-api-key",
    authDomain: "your-auth-domain",
    projectId: "your-project-id",
    storageBucket: "your-storage-bucket",
    messagingSenderId: "your-messaging-sender-id",
    appId: "your-app-id"
};

// 初始化Firebase
firebase.initializeApp(firebaseConfig);

// 导入其他模块
import { initAuth } from './auth.js';
import { initUI } from './ui.js';

// 创建Vue应用
const app = Vue.createApp({
    data() {
        return {
            username: '',
            password: '',
            showRegisterForm: false,
            registerData: {
                email: '',
                password: '',
                confirmPassword: ''
            }
        };
    },
    methods: {
        async login() {
            try {
                // 检查是否为测试账户
                if (this.username === 'admin' && this.password === 'admin') {
                    console.log('测试账户登录成功');
                    alert('登录成功！');
                    window.location.href = 'character.html';
                    return;
                }
                await firebase.auth().signInWithEmailAndPassword(this.username, this.password);
                // 登录成功后的处理
                console.log('登录成功');
                alert('登录成功！');
                window.location.href = 'character.html';
            } catch (error) {
                console.error('登录失败:', error.message);
                alert('登录失败：' + error.message);
            }
        },
        showRegister() {
            this.showRegisterForm = true;
        },
        hideRegister() {
            this.showRegisterForm = false;
            this.registerData = {
                email: '',
                password: '',
                confirmPassword: ''
            };
        },
        async register() {
            if (this.registerData.password !== this.registerData.confirmPassword) {
                console.error('两次输入的密码不一致');
                return;
            }
            try {
                await firebase.auth().createUserWithEmailAndPassword(
                    this.registerData.email,
                    this.registerData.password
                );
                console.log('注册成功');
                this.hideRegister();
            } catch (error) {
                console.error('注册失败:', error.message);
            }
        },
        showResetPassword() {
            // 显示重置密码界面
            console.log('显示重置密码界面');
        }
    },
    mounted() {
        // 初始化认证状态监听
        initAuth();
        // 初始化UI组件
        initUI();
    }
});

// 挂载Vue应用
app.mount('#app');