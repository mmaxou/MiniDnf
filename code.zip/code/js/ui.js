// UI组件初始化和管理
export function initUI() {
    // 初始化UI组件
    setupFormValidation();
    setupAnimations();
}

// 表单验证
function setupFormValidation() {
    const inputs = document.querySelectorAll('.form-control');
    inputs.forEach(input => {
        input.addEventListener('input', (e) => {
            validateInput(e.target);
        });
    });
}

// 输入验证
function validateInput(input) {
    if (input.value.length < 3) {
        input.classList.add('is-invalid');
        return false;
    }
    input.classList.remove('is-invalid');
    return true;
}

// 动画效果
function setupAnimations() {
    // 添加输入框焦点动画
    const runeInputs = document.querySelectorAll('.rune-border');
    runeInputs.forEach(input => {
        input.addEventListener('focus', () => {
            input.style.transform = 'scale(1.02)';
        });
        input.addEventListener('blur', () => {
            input.style.transform = 'scale(1)';
        });
    });

    // 添加按钮悬停效果
    const loginButton = document.querySelector('.btn-login');
    if (loginButton) {
        loginButton.addEventListener('mouseover', () => {
            loginButton.style.transform = 'translateY(-2px)';
        });
        loginButton.addEventListener('mouseout', () => {
            loginButton.style.transform = 'translateY(0)';
        });
    }
}

// 显示错误消息
export function showError(message) {
    // 这里可以添加错误提示UI组件
    console.error(message);
}

// 显示成功消息
export function showSuccess(message) {
    // 这里可以添加成功提示UI组件
    console.log(message);
}